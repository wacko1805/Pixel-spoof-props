# Pixel-spoof-props
Trick your device into thinking it a Google Pixel
Changes your device props to the ones of the Google Pixel 5

## Requirements:

* Magisk 18 or higher
* Android 10 or higher

## Installation:

 1. Flash the module in Magisk or TWRP
 2. Reboot
 3. Wait for system update and check updates for your apps
